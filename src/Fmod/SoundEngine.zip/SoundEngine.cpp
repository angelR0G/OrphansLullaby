#include "SoundEngine.hpp"
#include <iostream>
#include <cmath>
using namespace std;

//Funcion errcheck 
void ERRCHECK_FMOD (FMOD_RESULT result, const char * file, int line)
{
	if(result != FMOD_OK)
	{
        printf("%s, %s", result, FMOD_ErrorString(result));
		exit(-1);
	}
}
#define ERRCHECK(_result) ERRCHECK_FMOD(_result, __FILE__, __LINE__)


//Constructor
SoundEngine::SoundEngine(int size, int extraDriver) {

    system = nullptr;
    ERRCHECK( FMOD::Studio::System::create(&system) );
    ERRCHECK( system->getCoreSystem(&coreSystem) );
    ERRCHECK( coreSystem->setSoftwareFormat(0, FMOD_SPEAKERMODE_5POINT1, 0) );
    programmerSoundContext.sys = system;
    programmerSoundContext.coreSys = coreSystem;
    programmerSoundContext.dialogueString = "";
    
    if(extraDriver==0){
        extraDriverData = nullptr;
        //Common_Init(&extraDriverData);
        ERRCHECK( system->initialize(size, FMOD_STUDIO_INIT_NORMAL, FMOD_INIT_NORMAL, &extraDriverData) );
    }
    else{
        ERRCHECK( system->initialize(size, FMOD_STUDIO_INIT_LIVEUPDATE, FMOD_INIT_NORMAL, 0) );
    }

    
}

//Destructor
SoundEngine::~SoundEngine(){
    ERRCHECK( system->release() );
    banks.clear();
    eventDescriptions.clear();
    eventInstances.clear();
}

void SoundEngine::loadBank(string bankName){

    FMOD::Studio::Bank* newBank = nullptr;
    ERRCHECK( system->loadBankFile(bankName.c_str(), FMOD_STUDIO_LOAD_BANK_NORMAL, &newBank) );
    banks.insert(pair<string, FMOD::Studio::Bank*>(bankName, newBank));

}

void SoundEngine::unloadBank(string bankName){

    ERRCHECK( banks.find(bankName)->second->unload() );
    banks.erase(bankName);

}

void SoundEngine::createDescriptor(string eventPath, uint16_t descriptorID){

    FMOD::Studio::EventDescription* eventDescription = nullptr;
    ERRCHECK( system->getEvent(eventPath.c_str(), &eventDescription) ); 
    eventDescriptions.insert(std::pair<uint16_t, FMOD::Studio::EventDescription*>(descriptorID, eventDescription));

}

FMOD::Studio::EventDescription* SoundEngine::getDescriptor(uint16_t descriptorID){

    unordered_map<uint16_t, FMOD::Studio::EventDescription*>::iterator eventFound = eventDescriptions.find(descriptorID);

    if(eventFound!=eventDescriptions.end()){

        return eventFound->second;
    }
    
    return nullptr;


}

uint16_t SoundEngine::createInstance(uint16_t descriptorID){
    FMOD::Studio::EventDescription* eventDescription = getDescriptor(descriptorID);
    FMOD::Studio::EventInstance* eventInstance = nullptr;
    ERRCHECK( eventDescription->createInstance(&eventInstance) );
    for(uint16_t i = 0; i<eventInstances.size(); i++){
        if(eventInstances[i]==nullptr){
            eventInstances[i]=eventInstance;
            return i;
        }
    }
    //ERRCHECK( eventInstance->setCallback(soundCallback,  FMOD_STUDIO_EVENT_CALLBACK_STOPPED | FMOD_STUDIO_EVENT_CALLBACK_STARTED| FMOD_STUDIO_EVENT_CALLBACK_SOUND_STOPPED) );
    // uint8_t userData = 0;
    // void *pointer = (void *)userData;
    // eventInstance->setUserData(pointer);
    eventInstances.push_back(eventInstance);
    return eventInstances.size()-1;

}

uint16_t SoundEngine::createInstance(uint16_t descriptorID, Transform coords){
    FMOD::Studio::EventDescription* eventDescription = getDescriptor(descriptorID);
    FMOD::Studio::EventInstance* eventInstance = nullptr;
    ERRCHECK( eventDescription->createInstance(&eventInstance) );
    for(uint16_t i = 0; i<eventInstances.size(); i++){
        if(eventInstances[i]==nullptr){
            eventInstances[i]=eventInstance;
            return i;
        }
    }
    //ERRCHECK( eventInstance->setCallback(soundCallback,  FMOD_STUDIO_EVENT_CALLBACK_STOPPED | FMOD_STUDIO_EVENT_CALLBACK_STARTED| FMOD_STUDIO_EVENT_CALLBACK_SOUND_STOPPED) );
    // uint8_t userData = 0;
    // void *pointer = (void *)userData;
    // eventInstance->setUserData(pointer);

    double nrx = sin(coords.rx);
    double nrz = cos(coords.rx);
    FMOD_3D_ATTRIBUTES attributes {FMOD_VECTOR{coords.x, coords.y, coords.z}, FMOD_VECTOR{0, 0, 0}, FMOD_VECTOR{(float)nrx, 0, (float)nrz}, FMOD_VECTOR{0, 1, 0}};
    ERRCHECK(eventInstance->set3DAttributes(&attributes));
    eventInstances.push_back(eventInstance);
    return eventInstances.size()-1;

}

uint16_t SoundEngine::prepareSound(string eventPath, uint16_t descriptorID, bool is3D, Transform coords){

    
    if(eventDescriptions.find(descriptorID)==eventDescriptions.end()){

        createDescriptor(eventPath, descriptorID);

    }
    if(is3D){
        return createInstance(descriptorID, coords);
    }
    return createInstance(descriptorID);
    

}

void SoundEngine::update3DListener(Transform coords){
    
    double nrx = sin(coords.rx);
    double nrz = cos(coords.rx);
    FMOD_3D_ATTRIBUTES attributes {FMOD_VECTOR{coords.x, coords.y, coords.z}, FMOD_VECTOR{0, 0, 0}, FMOD_VECTOR{(float)nrx, 0, (float)nrz}, FMOD_VECTOR{0, 1, 0}};
    ERRCHECK(system->setListenerAttributes(0, &attributes));
}

// uint16_t SoundEngine::createSound(string eventPath, Transform positions){
//     FMOD::Sound* sound = nullptr;
//     ERRCHECK(coreSystem->createSound(eventPath.c_str(), FMOD_3D, 0, &sound));
//     sound->
//     sounds.push_back(sound);
//     return sounds.size()-1;
// }

void SoundEngine::setParameter(string parameterName, uint8_t parameterValue, uint16_t instanceIndex, uint16_t descriptorID){
    
    unordered_map<uint16_t, FMOD::Studio::EventDescription*>::iterator eventFound = eventDescriptions.find(descriptorID);

    if(eventFound!=eventDescriptions.end()){
        ERRCHECK( eventFound->second->getParameterDescriptionByName(parameterName.c_str(), &paramDesc) );
        parameterID = paramDesc.id;
        ERRCHECK( eventInstances[instanceIndex]->setParameterByID(parameterID, parameterValue) );
    }


}

void SoundEngine::playSound(uint16_t instanceIndex){
    
    // void *pointer;
    // eventInstances[instanceIndex]->getUserData(&pointer);
    // uint64_t canPlay = (uint64_t)pointer;
    // std::cout << "AAAAAAA. " << canPlay << "\n";
    // if(canPlay == 0){
        ERRCHECK( eventInstances[instanceIndex]->start() );
        ERRCHECK( eventInstances[instanceIndex]->release() );
    //}
}

void SoundEngine::update(){
    ERRCHECK( system->update() );
}

uint16_t SoundEngine::prepareDialogue(string evenPath, uint16_t descriptorID){

    uint16_t dev = prepareSound(evenPath, descriptorID, false, Transform(std::vector<float>{}));
    ERRCHECK( eventInstances[dev]->setUserData(&programmerSoundContext) );
    ERRCHECK( eventInstances[dev]->setCallback(programmerSoundCallback, FMOD_STUDIO_EVENT_CALLBACK_CREATE_PROGRAMMER_SOUND | FMOD_STUDIO_EVENT_CALLBACK_DESTROY_PROGRAMMER_SOUND) );
    return dev;

}

void SoundEngine::playDialogue(uint16_t instanceIndex, const char* dialogue){

    programmerSoundContext.dialogueString = dialogue;
    ERRCHECK( eventInstances[instanceIndex]->start() );


}



#define CHECK_RESULT(op) \
    { \
        FMOD_RESULT res = (op); \
        if (res != FMOD_OK) \
        { \
            return res; \
        } \
    }



FMOD_RESULT F_CALLBACK SoundEngine::programmerSoundCallback(FMOD_STUDIO_EVENT_CALLBACK_TYPE type, FMOD_STUDIO_EVENTINSTANCE* event, void *parameters)
{
    FMOD::Studio::EventInstance* eventInstance = (FMOD::Studio::EventInstance*)event;

    if (type == FMOD_STUDIO_EVENT_CALLBACK_CREATE_PROGRAMMER_SOUND)
    {
        FMOD_STUDIO_PROGRAMMER_SOUND_PROPERTIES* props = (FMOD_STUDIO_PROGRAMMER_SOUND_PROPERTIES*)parameters;

        // Get our context from the event instance user data
        ProgrammerSoundContext* context = NULL;
        CHECK_RESULT( eventInstance->getUserData((void**)&context) );

        // Find the audio file in the audio table with the key
        FMOD_STUDIO_SOUND_INFO info;
        CHECK_RESULT( context->sys->getSoundInfo(context->dialogueString, &info) );

        FMOD::Sound* sound = NULL;
        CHECK_RESULT( context->coreSys->createSound(info.name_or_data, FMOD_LOOP_NORMAL | FMOD_CREATECOMPRESSEDSAMPLE | FMOD_NONBLOCKING | info.mode, &info.exinfo, &sound) );

        // Pass the sound to FMOD
        props->sound = (FMOD_SOUND*)sound;
        props->subsoundIndex = info.subsoundindex;
    }
    else if (type == FMOD_STUDIO_EVENT_CALLBACK_DESTROY_PROGRAMMER_SOUND)
    {
        FMOD_STUDIO_PROGRAMMER_SOUND_PROPERTIES* props = (FMOD_STUDIO_PROGRAMMER_SOUND_PROPERTIES*)parameters;

        // Obtain the sound
        FMOD::Sound* sound = (FMOD::Sound*)props->sound;

        // Release the sound
        CHECK_RESULT( sound->release() );
    }

    return FMOD_OK;
}


FMOD_RESULT F_CALLBACK SoundEngine::soundCallback(FMOD_STUDIO_EVENT_CALLBACK_TYPE type, FMOD_STUDIO_EVENTINSTANCE* event, void *parameters)
{
    // FMOD::Studio::EventInstance* eventInstance = (FMOD::Studio::EventInstance*)event;

    // if(type == FMOD_STUDIO_EVENT_CALLBACK_STARTED){
    //     std::cout << "a\n";
    //     uint8_t userData = 1;
    //     void *pointer = (void *)userData;
    //     eventInstance->setUserData(pointer);
        
    // }else if(type == FMOD_STUDIO_EVENT_CALLBACK_SOUND_STOPPED){
    //     std::cout << "b\n";
    //     uint8_t userData = 0;
    //     void *pointer = (void *)userData;
    //     eventInstance->setUserData(pointer);
    // }
    // event = (FMOD_STUDIO_EVENTINSTANCE*)eventInstance;
    return FMOD_OK;
}

