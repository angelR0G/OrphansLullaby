/*
Este archivo sirve como fachada a la hora de usar un motor de sonido en el videojuego
*/

/*
Seccion para realizar los includes necesarios
*/

#pragma once

#include <linux/fmod/inc/fmod_studio.hpp>
#include <linux/fmod/core/inc/fmod.hpp>
#include <linux/fmod/core/inc/fmod_errors.h>
#include <vector>
#include <cstdint>
#include <string>
#include <unordered_map>
#include "../utils/transform.hpp"


#define INCLUDE_EXTRA_DRIVER_DATA 0
#define EXCLUDE_EXTRA_DRIVER_DATA 1

using namespace std;

struct ProgrammerSoundContext{
    FMOD::System* coreSys;
    FMOD::Studio::System* sys;
    const char* dialogueString;
};

class SoundEngine{

    /*
    Seccion para los metodos
    */
    public:
        SoundEngine(int,int);
        ~SoundEngine();
        void loadBank(string);
        void unloadBank(string);
        void createDescriptor(string, uint16_t);
        uint16_t createInstance(uint16_t);
        uint16_t createInstance(uint16_t, Transform);
        uint16_t prepareSound(string, uint16_t, bool, Transform);
        void update3DListener(Transform);
        // uint16_t createSound(string, Transform);
        FMOD::Studio::EventDescription* getDescriptor(uint16_t);
        void setParameter(string, uint8_t, uint16_t, uint16_t);
        void playSound(uint16_t);
        static FMOD_RESULT F_CALLBACK programmerSoundCallback(FMOD_STUDIO_EVENT_CALLBACK_TYPE type, FMOD_STUDIO_EVENTINSTANCE* event, void *parameters);
        static FMOD_RESULT F_CALLBACK soundCallback(FMOD_STUDIO_EVENT_CALLBACK_TYPE type, FMOD_STUDIO_EVENTINSTANCE* event, void *parameters);
        uint16_t prepareDialogue(string, uint16_t);
        void playDialogue(uint16_t, const char*);
        void update();
    


    private:

        void *extraDriverData; //informacion extra de los drivers del equipo
        FMOD::Studio::System* system; //puntero a system para hacer funcionar el resto de funciones
        FMOD::System* coreSystem;
        std::unordered_map<string, FMOD::Studio::Bank*> banks;
        std::unordered_map<uint16_t, FMOD::Studio::EventDescription*> eventDescriptions;
        std::vector<FMOD::Studio::EventInstance*> eventInstances;
        std::vector<FMOD::Sound*> sounds;
        FMOD_STUDIO_PARAMETER_DESCRIPTION paramDesc;
        FMOD_STUDIO_PARAMETER_ID parameterID;
        ProgrammerSoundContext programmerSoundContext;
};



